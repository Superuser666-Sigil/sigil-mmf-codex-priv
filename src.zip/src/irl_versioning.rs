pub fn current_model_id() -> &'static str {
    "sigil_trust_v1"
}

pub fn model_version_tag() -> &'static str {
    "v0.1.0-alpha"
}