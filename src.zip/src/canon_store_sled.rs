pub struct CanonStoreSled;

impl CanonStoreSled {
    pub fn new() -> Self {
        CanonStoreSled
    }
}
