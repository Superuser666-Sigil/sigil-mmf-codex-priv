pub fn validate_elevation(_: &str) -> bool { true }
